<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>HVTFALoopWorker</name>
    <message>
        <location filename="../src/HVTFALoop.cpp" line="94"/>
        <source>Station %1 : Morlet wavelet convolution at %2 Hz for component %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVTFAPlugin</name>
    <message>
        <location filename="../src/HVTFAPlugin.cpp" line="53"/>
        <source>H/V TFA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAPlugin.cpp" line="55"/>
        <source>Rayleigh ellipticity based on Morlet wavelet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAPlugin.h" line="42"/>
        <source>H/V Time Frequency Analysis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVTFAStationSignals</name>
    <message>
        <location filename="../src/HVTFAStationSignals.cpp" line="72"/>
        <location filename="../src/HVTFAStationSignals.cpp" line="79"/>
        <source>Creating array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAStationSignals.cpp" line="73"/>
        <source>The samling rate must be the same for all components.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAStationSignals.cpp" line="80"/>
        <source>The differences between t0s must be a multiple of sampling period. Problem with signal ID %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAStationSignals.cpp" line="95"/>
        <source>Saving log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAStationSignals.cpp" line="96"/>
        <source>Unable to open file %1 for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVTFAStationSignals.cpp" line="114"/>
        <source>No signal available for station %1 between times %2 and %3
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolHVTFA</name>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="86"/>
        <source>Initializing stations...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="87"/>
        <source>H/V TFA toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="97"/>
        <source>Detected less than 3 components
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="99"/>
        <source>Checking stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="135"/>
        <source>Station %1 (range %2/%3): computing fourier spectra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="144"/>
        <source>%1, range %2/%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="156"/>
        <source>H/V Time Frequency Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="157"/>
        <source>Cannot open file %1 for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="169"/>
        <source>H/V TFA completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFA.cpp" line="178"/>
        <source>HVTFA computation stopped</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolHVTFAd</name>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="13"/>
        <source>H/V TFA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="31"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="43"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li {white-space: pre-wrap;}
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Modified Morlet Wavelet in spectral domain:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;M=1/pow(pi,0.25)*exp(w0*f/fi - w0)/ m&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;w0, m0 are the wavelet parameters. Theoretically w0&amp;gt;5.5. A typical value for w0 is 6. A typical value for m0 is 10.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;fi is the analysed frequency.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="56"/>
        <source>Wavelet parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="68"/>
        <source>Frequency range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="77"/>
        <source>Comments on frequency resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="89"/>
        <source>Output directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="99"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="126"/>
        <source>Load parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="149"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.ui" line="159"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.cpp" line="48"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.cpp" line="53"/>
        <source>This is just for computing the resolution in time and frequency. It has no influence on the computation of the Morlet transform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.cpp" line="78"/>
        <source>H/V Time frequency Analysis output file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolHVTFAd.cpp" line="78"/>
        <source>Output max files (*.max)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
