<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>QGpCoreTools::AbstractParameters</name>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="189"/>
        <location filename="../src/AbstractParameters.cpp" line="200"/>
        <location filename="../src/AbstractParameters.cpp" line="272"/>
        <location filename="../src/AbstractParameters.cpp" line="300"/>
        <source>Loading parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="190"/>
        <location filename="../src/AbstractParameters.cpp" line="301"/>
        <source>Parameter file (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="201"/>
        <source>Unable to open file &apos;%1&apos; for reading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="273"/>
        <source>Unknown keyword &apos;%1&apos; or error setting value &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="313"/>
        <source>Saving parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="314"/>
        <source>Unable to open file &apos;%s&apos; for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="328"/>
        <source>Obsolete keyword &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="330"/>
        <source>Obsolete keyword with unknown name (index=%1)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="343"/>
        <source>Fix keywordCount: %1 instead of %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::AbstractParameters::KeywordMap</name>
    <message>
        <location filename="../src/AbstractParameters.cpp" line="50"/>
        <source>Setting &apos;%1 (%2)&apos; with value &apos;%3&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ApplicationHelp</name>
    <message>
        <location filename="../src/ApplicationHelp.cpp" line="150"/>
        <source>Usage: %1 %2

</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ArgumentStdinReader</name>
    <message>
        <location filename="../src/ArgumentStdinReader.cpp" line="74"/>
        <location filename="../src/ArgumentStdinReader.cpp" line="115"/>
        <source>Cannot open file &apos;%1&apos; for reading.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ArgumentStdinReader.cpp" line="79"/>
        <location filename="../src/ArgumentStdinReader.cpp" line="120"/>
        <source>Reading file &apos;%1&apos;...
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::AsciiLineParser</name>
    <message>
        <location filename="../src/AsciiLineParser.cpp" line="380"/>
        <source>Unmatched single quote at index %1.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AsciiLineParser.cpp" line="403"/>
        <source>Unmatched double quote at index %1.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AsciiLineParser.cpp" line="653"/>
        <location filename="../src/AsciiLineParser.cpp" line="673"/>
        <source>TAB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AsciiLineParser.cpp" line="657"/>
        <location filename="../src/AsciiLineParser.cpp" line="676"/>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AsciiLineParser.cpp" line="661"/>
        <location filename="../src/AsciiLineParser.cpp" line="679"/>
        <source>Coma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/AsciiLineParser.cpp" line="665"/>
        <location filename="../src/AsciiLineParser.cpp" line="682"/>
        <source>Semicolon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Cache</name>
    <message>
        <location filename="../src/Cache.cpp" line="125"/>
        <source>Saving item %1
Freeing %2 Kb from item %3		Free space=%4 Kb
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="149"/>
        <source>Saving item %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="158"/>
        <source>Freeing %1 Kb from item %2. %3 still allocated		free space=%4 Kb
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="180"/>
        <location filename="../src/Cache.cpp" line="234"/>
        <source>Impossible to allocate new data
   current used space: %1 Kb
   current free space: %2 Kb
   current buffer size: %3 Kb
   required space: %4 Kb
Increase buffer size, a good compromize is 80% of you physical memory
This buffer is allocated dynamically upon requests, so it will not overload
your memory usage.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="202"/>
        <source>Loading item %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="207"/>
        <source>Allocating %1 Kbytes for item %2		free space=%3 Kb
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="214"/>
        <source>Impossible to allocate new data of size %1: current used space: %2 Kb.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="322"/>
        <source>%1 allocated blocks (%2 Mb), %3 locked blocks (%4 Mb)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="333"/>
        <source>#### Cache debug status %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="339"/>
        <source>#### %1 %2 kb locked %3 times (trylock success)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="344"/>
        <location filename="../src/Cache.cpp" line="356"/>
        <source>#### %1 %2 kb unlocked
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="351"/>
        <source>#### %1 %2 kb locked %3 times (trylock failed)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Cache.cpp" line="363"/>
        <source>#### ---------------
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ColumnTextFile</name>
    <message>
        <location filename="../src/ColumnTextFile.cpp" line="72"/>
        <source>Empty file name
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextFile.cpp" line="78"/>
        <source>Cannot read file &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ColumnTextParser</name>
    <message>
        <location filename="../src/ColumnTextParser.cpp" line="182"/>
        <source>Skipped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextParser.cpp" line="193"/>
        <source>Maximum column index is %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextParser.cpp" line="570"/>
        <source>No column index defined for description
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ColumnTextParser.cpp" line="652"/>
        <source>error parsing &apos;%1&apos; from &apos;%2&apos; at column %3 and line %4
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::CoreApplicationPrivate</name>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="169"/>
        <source>Negative or null maximum number of parallel jobs: &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="173"/>
        <source>Too many parallel jobs compared to the number of physical cores (option -j or -jobs).
Maximum value is %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="243"/>
        <source>Thead affinity mask cannot be accessed, skipping CPU affinity optimization
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="262"/>
        <source>CPU affinity[%1]=%2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="814"/>
        <source>User interrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="815"/>
        <source>Is this process blocked? Answer &apos;Yes&apos; to generate a bug report.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="864"/>
        <source>
A bug report has just been generated (%1).
To help debugging this software, please open it in a web browser.
You will be redirected to http://www.geopsy.org/bugs/backtrace.php.
We sincerely apologize for the inconvenience.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="869"/>
        <source>
To help debugging this software, please open a web browser
and submit this bug report to http://www.geopsy.org/bugs/backtrace.php.
We sincerely apologize for the inconvenience.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1011"/>
        <source>Shows help. ARG may be a level (0,1,2...) or a section keyword. Accepted keywords are: all, html, latex, generic, debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1016"/>
        <source>Generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1017"/>
        <source>-h, -help [ARG]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1018"/>
        <source>-args [MAX]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1018"/>
        <source>List the argument history diplaying MAX entries (default=50). Üse &apos;-args 0&apos; to print all entries recorded so far.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1020"/>
        <source>-rargs [INDEX]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1020"/>
        <source>Reuse argument list with INDEX. See &apos;-args&apos; to get the available argument lists. Wihtout INDEX the last argument list is used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1022"/>
        <source>-version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1022"/>
        <source>Show version information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1023"/>
        <source>-app-version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1023"/>
        <source>Show short version information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1024"/>
        <source>-j, -jobs &lt;N&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1024"/>
        <source>Allow a maximum of N simulteneous jobs for parallel computations (default=%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1026"/>
        <source>-verbosity &lt;V&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1026"/>
        <source>Set level of verbosity (default=0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1027"/>
        <source>-locale &lt;L&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1027"/>
        <source>Set current locale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1028"/>
        <source>-batch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1028"/>
        <source>Prevent the storage of user history (e.g. -args or recent file menus). Use it when running inside a script, to prevent pollution of user history.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1030"/>
        <source>-qt-plugin-paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1030"/>
        <source>Print the list of paths where Qt plugins are search.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1031"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1032"/>
        <source>-nobugreport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1033"/>
        <source>Does not generate bug reports in case of error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1034"/>
        <source>-reportbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1035"/>
        <source>Starts bug report dialog, information about bug is passed through stdin. This option is used internally to report bugs if option -nobugreport is not specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1038"/>
        <source>-warning-critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1039"/>
        <source>Consider warnings as critical, stops execution and issue a bug report. Mainly used for debug, to be able to start the debugger even after a warning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1041"/>
        <source>-reportint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1042"/>
        <source>Starts bug report dialog, information about interruption is passed through stdin. This option is used internally to report interruptions if option -nobugreport is not specified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1045"/>
        <source>-sleep &lt;S&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1046"/>
        <source>Sleep for S seconds at the beginning to let, for instance, a debugger to connect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1073"/>
        <source>Option &apos;%1&apos; requires an argument, see -help for details.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1092"/>
        <source>bad option &apos;%1&apos;, see -help for details.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1109"/>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1130"/>
        <source>Error converting numerical value: &apos;%1&apos; for option &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1113"/>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1134"/>
        <source>Error converting numerical value: &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1193"/>
        <source>File &apos;%1&apos; not found
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1449"/>
        <source># History of command line arguments:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1532"/>
        <source>Bad argument list index (%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1537"/>
        <source>Bad argument list index (%1&gt;=%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1542"/>
        <source>To prevent inifinte looping, &apos;-rargs&apos; option is not allowed in argument list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/CoreApplicationPrivate.cpp" line="1546"/>
        <source>Starting &apos;%1 %2&apos;...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::DateTimeFromString</name>
    <message>
        <location filename="../src/DateTime.cpp" line="352"/>
        <source>truncated date/time specification: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="362"/>
        <source>unmatched characters: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="367"/>
        <source>not a valid date
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="372"/>
        <location filename="../src/DateTime.cpp" line="376"/>
        <source>%1 is not on a %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="385"/>
        <location filename="../src/DateTime.cpp" line="392"/>
        <source>not a valid hour with am/pm
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="400"/>
        <source>not a valid time
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="424"/>
        <location filename="../src/DateTime.cpp" line="445"/>
        <source>expected a number between 1 and 31: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="463"/>
        <source>expected a valid short day name: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="481"/>
        <source>expected a valid long day name: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="506"/>
        <location filename="../src/DateTime.cpp" line="527"/>
        <source>expected a number between 1 and 12: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="545"/>
        <source>expected a valid short month name: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="563"/>
        <source>expected a valid long month name: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="582"/>
        <source>expected a number between 0 and 99: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="609"/>
        <source>expected a number between 0 and 9999: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="632"/>
        <location filename="../src/DateTime.cpp" line="653"/>
        <source>expected a number between 0 and 23: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="676"/>
        <location filename="../src/DateTime.cpp" line="697"/>
        <source>expected a number between 0 and 12: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="720"/>
        <location filename="../src/DateTime.cpp" line="741"/>
        <location filename="../src/DateTime.cpp" line="764"/>
        <location filename="../src/DateTime.cpp" line="785"/>
        <source>expected a number between 0 and 59: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="812"/>
        <location filename="../src/DateTime.cpp" line="837"/>
        <source>expected a decimal number between 0 and 60 (excluding 60): &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="862"/>
        <source>expected a number between 0 and 999: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="879"/>
        <source>expected a number between 000 and 999: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="898"/>
        <source>expected am or pm: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="917"/>
        <source>expected AM or PM: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="931"/>
        <source>expected &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="939"/>
        <source>wrong character: &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::DateTimeParser</name>
    <message>
        <location filename="../src/DateTime.cpp" line="116"/>
        <source>error parsing time &apos;%1&apos;
                    %2^
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DateTime.cpp" line="274"/>
        <source>unterminated quoted text
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ExpressionAction</name>
    <message>
        <location filename="../src/ExpressionAction.cpp" line="396"/>
        <location filename="../src/ExpressionAction.cpp" line="405"/>
        <location filename="../src/ExpressionAction.cpp" line="409"/>
        <location filename="../src/ExpressionAction.cpp" line="419"/>
        <source>Division by zero
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ExpressionParser</name>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="110"/>
        <source>Not a valid argument, syntax error %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="125"/>
        <source>Unmatched bracket %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="135"/>
        <source>Square brackets allowed only for arrays: %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="140"/>
        <source>Unmatched square bracket %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="149"/>
        <source>No coma expected here %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="165"/>
        <source>Not a valid operator, syntax error %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="391"/>
        <source>Unrecognized character %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="398"/>
        <source>at line %1 and column %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionParser.cpp" line="407"/>
        <source>Unmatched &quot; before reaching the end of buffer
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ExpressionString</name>
    <message>
        <location filename="../src/ExpressionString.cpp" line="64"/>
        <source>Unmatched &apos;{&apos; before reaching the end of buffer
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExpressionString.cpp" line="118"/>
        <source>Unmatched &quot; before reaching the end of buffer
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::File</name>
    <message>
        <location filename="../src/File.cpp" line="53"/>
        <source>Cannot open file &apos;%1&apos; for checksum computation.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/File.cpp" line="143"/>
        <location filename="../src/File.cpp" line="162"/>
        <source>cannot access %1
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::FileStream</name>
    <message>
        <location filename="../src/FileStream.cpp" line="51"/>
        <source>warning: cannot open file %1
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Leds</name>
    <message>
        <location filename="../src/Leds.cpp" line="62"/>
        <source>no led available
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Leds.cpp" line="137"/>
        <source>setTrigger: error writing to %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Leds.cpp" line="156"/>
        <source>power: error writing to %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Leds.cpp" line="178"/>
        <source>setDelayOn: error writing to %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Leds.cpp" line="200"/>
        <source>setDelayOff: error writing to %1
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::LoopWorker</name>
    <message>
        <location filename="../src/ParallelLoop.cpp" line="55"/>
        <source>Thead affinity mask cannot be set to %1, skipping CPU affinity optimization
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Message</name>
    <message>
        <location filename="../src/Message.cpp" line="141"/>
        <source>-----INFO----- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="143"/>
        <source>----WARNING--- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="145"/>
        <source>----ERROR----- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="147"/>
        <source>--FATAL ERROR- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="149"/>
        <source>---QUESTION--- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="151"/>
        <source>-------------- </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="179"/>
        <source> &lt;-- default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="184"/>
        <source>? </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="205"/>
        <source>Show this message again? [y]/n </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="347"/>
        <location filename="../src/Message.cpp" line="375"/>
        <location filename="../src/Message.cpp" line="403"/>
        <source>  Filter: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="348"/>
        <location filename="../src/Message.cpp" line="404"/>
        <source>  Current directory: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="354"/>
        <source>File to open: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="376"/>
        <source>  Selection: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="382"/>
        <source>File to save: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="412"/>
        <source>File %1 to open: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="431"/>
        <source>  Dir: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="437"/>
        <source>Directory to choose: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="457"/>
        <location filename="../src/Message.cpp" line="505"/>
        <source>Error parsing text file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="459"/>
        <source>Error parsing text
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="465"/>
        <source>Offset from beginning of file: %1 bytes.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="470"/>
        <location filename="../src/Message.cpp" line="483"/>
        <location filename="../src/Message.cpp" line="518"/>
        <location filename="../src/Message.cpp" line="535"/>
        <source>    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="476"/>
        <location filename="../src/Message.cpp" line="526"/>
        <source>==&gt; %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="488"/>
        <source>Impossible to print the context of the parsing error
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.cpp" line="503"/>
        <source>Error parsing text file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="113"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="114"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="115"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="116"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="117"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="118"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="119"/>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="120"/>
        <source>Ignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="121"/>
        <source>Yes to all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Message.h" line="122"/>
        <source>No to all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Mutex</name>
    <message>
        <location filename="../src/Mutex.cpp" line="48"/>
        <source>[MUTEX] %1 ms in lock() in %2:%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Mutex.cpp" line="64"/>
        <source>[MUTEX] %1 ms in lock()
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Number</name>
    <message>
        <location filename="../src/Number.cpp" line="210"/>
        <source>Number::toBinaryCodedDecimal: overflow, value&gt;=100
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Number.cpp" line="226"/>
        <source>Number::toBinaryCodedDecimal: overflow, value&gt;=10,000
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Number.cpp" line="254"/>
        <source>Number::toBinaryCodedDecimal: overflow, value&gt;=100,000,000
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Number.cpp" line="376"/>
        <source>Error parsing time &apos;%1&apos; at position %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ParallelLoop</name>
    <message>
        <location filename="../src/ParallelLoop.cpp" line="152"/>
        <source>error creating new worker, see above log
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParallelLoop.cpp" line="176"/>
        <source>Running loop without parallel threads
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParallelLoop.cpp" line="186"/>
        <source>Running loop with %1 parallel threads
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParallelLoop.cpp" line="199"/>
        <source>Assign affinity %1 to worker %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ParallelTask</name>
    <message>
        <location filename="../src/ParallelTask.cpp" line="85"/>
        <source>  task index %1: progress %2 %
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParallelTask.cpp" line="93"/>
        <source>  task index %1: processed during %2 s
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ParallelTask.cpp" line="98"/>
        <source>  task index %1: progress 100 %
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::PathTranslator</name>
    <message>
        <location filename="../src/PathTranslator.cpp" line="139"/>
        <source>Please select file &apos;%1&apos; in its new location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PathTranslator.cpp" line="146"/>
        <source>Selected file is not the correct file. Aborting.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::PathTranslatorOptions</name>
    <message>
        <location filename="../src/PathTranslatorOptions.cpp" line="46"/>
        <source>File &apos;%1&apos; does not exist or cannot be accessed.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PathTranslatorOptions.cpp" line="72"/>
        <source>The path may have changed. Would you like to manually select its new location?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ReadWriteLock</name>
    <message>
        <location filename="../src/ReadWriteLock.cpp" line="47"/>
        <source>[MUTEX] %1 ms in lockForRead() in %2:%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ReadWriteLock.cpp" line="62"/>
        <source>[MUTEX] %1 ms in lockForWrite() in %2:%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ReadWriteLock.cpp" line="77"/>
        <source>[MUTEX] %1 ms in lockForRead()
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ReadWriteLock.cpp" line="92"/>
        <source>[MUTEX] %1 ms in lockForWrite()
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::ScriptContext</name>
    <message>
        <location filename="../src/ScriptContext.cpp" line="105"/>
        <source>addSeconds cannot convert time string.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ScriptContext.cpp" line="117"/>
        <source>addMonths cannot convert time string.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ScriptContext.cpp" line="129"/>
        <source>addYears cannot convert time string.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ScriptContext.cpp" line="139"/>
        <source>elapsedSeconds cannot convert first time string.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ScriptContext.cpp" line="142"/>
        <source>elapsedSeconds cannot convert second time string.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Tar</name>
    <message>
        <location filename="../src/Tar.cpp" line="115"/>
        <source>Tar: Unsupported file mode access
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="215"/>
        <source>File names greater than 99 charaters are currently not supported
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="267"/>
        <source>Cannot read file in archive: bad header block, magic!=ustar
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="271"/>
        <source>Cannot read file in archive: bad header block, typeflag!=0
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="277"/>
        <source>Cannot read file in archive: bad header block, computed checksum (%1)!=saved checksum (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="284"/>
        <source>Negative file size in tar archive.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="289"/>
        <source>File size must less than 256Mb.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.cpp" line="329"/>
        <source>Cannot convert %1 to octal with 11 digit
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.h" line="77"/>
        <source>Cannot write block in tar file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tar.h" line="89"/>
        <source>Cannot read a block of 512 bytes in tar file
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::TreeContainer</name>
    <message>
        <location filename="../src/TreeContainer.cpp" line="63"/>
        <source>TreeContainer::takeChild: unknown child.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::UniqueID</name>
    <message>
        <location filename="../src/UniqueID.cpp" line="71"/>
        <source> ID %1 changed to %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::Version</name>
    <message>
        <location filename="../src/Version.cpp" line="80"/>
        <source>error parsing version &apos;%1&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::XMLByteArrayStream</name>
    <message>
        <location filename="../src/XMLByteArrayStream.cpp" line="86"/>
        <source>Wrong tag, not a XMLClass byte array
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLByteArrayStream.cpp" line="92"/>
        <source>Wrong version(%1), current version is %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::XMLClass</name>
    <message>
        <location filename="../src/XMLClass.cpp" line="450"/>
        <source>Cannot open file. Check file permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="453"/>
        <source>Cannot write to file. Check disk space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="456"/>
        <source>No doc type found at the beginning of the XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="459"/>
        <source>No version found at the beginning of the XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="462"/>
        <source>Unmatched ampersand and semi colon for XML special characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="465"/>
        <source>Unknwown XML special character</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="468"/>
        <source>Empty XML tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="471"/>
        <source>Unmatched XML tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="474"/>
        <source>Unmatched top level XML tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="477"/>
        <source>Empty context stack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="480"/>
        <source>Error parsing tag content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="483"/>
        <source>Error parsing tag attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="486"/>
        <source>Error setting tag attributes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="489"/>
        <source>Error setting binary data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="492"/>
        <source>Wrong offset in binary file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="495"/>
        <source>Wrong binary tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="498"/>
        <source>Binary file not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="501"/>
        <source>Truncated tag at the end of XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="504"/>
        <source>Truncated string at the end of XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="507"/>
        <source>Truncated context at the end of XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="510"/>
        <source>Object not completely restored at the end of XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="513"/>
        <source>Object not found in XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="516"/>
        <source>Error while polishing the object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="521"/>
        <source> (%1 at line %2).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="523"/>
        <source> (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="526"/>
        <source> (at line %1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLClass.cpp" line="588"/>
        <source>read-only property : %1
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::XMLErrorReport</name>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="71"/>
        <location filename="../src/XMLErrorReport.cpp" line="94"/>
        <source>An error occurred while reading from file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="73"/>
        <location filename="../src/XMLErrorReport.cpp" line="96"/>
        <source>An error occurred while writing to file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="86"/>
        <source>An error occurred while reading XML content
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="88"/>
        <source>An error occurred while writing XML content
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="90"/>
        <source>An error occurred while accesing XML content
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="98"/>
        <source>An error occurred while accessing file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLErrorReport.cpp" line="103"/>
        <source>
Details:
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::XMLHeader</name>
    <message>
        <location filename="../src/XMLHeader.cpp" line="93"/>
        <source>Cannot write to file %1.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLHeader.cpp" line="98"/>
        <location filename="../src/XMLHeader.cpp" line="114"/>
        <source>Cannot open file %1 for writing.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLHeader.cpp" line="176"/>
        <source>No contents.xml found in archive, trying old versions...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLHeader.cpp" line="255"/>
        <source>Wrong DOCTYPE at line 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLHeader.cpp" line="263"/>
        <source>Missing &apos;&gt;&apos; at line 
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGpCoreTools::XMLParser</name>
    <message>
        <location filename="../src/XMLParser.cpp" line="199"/>
        <source>Unknown tag at line %1 for context %2: %3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLParser.cpp" line="220"/>
        <location filename="../src/XMLParser.cpp" line="811"/>
        <source>Looking for tag &apos;%1&apos;, found &apos;%2&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLParser.cpp" line="337"/>
        <source>Expecting tag %1, and found %2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/XMLParser.cpp" line="688"/>
        <source>No value given for attribute %1 at line %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
