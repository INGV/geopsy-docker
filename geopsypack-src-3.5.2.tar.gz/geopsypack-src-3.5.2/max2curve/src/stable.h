#if defined __cplusplus
#include <QtGui>
#include <QtWidgets>
#ifndef Q_OS_MAC
#include <QGpCoreTools.h>
#include <QGpGuiTools.h>
#include <QGpCoreMath.h>
#include <QGpGuiMath.h>
#include <SciFigs.h>
#include <QGpCoreWave.h>
#include <QGpGuiWave.h>
#endif // Q_OS_MAC
#endif // __cplusplus
