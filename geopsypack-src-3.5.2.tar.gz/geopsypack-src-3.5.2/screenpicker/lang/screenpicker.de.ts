<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>MouseGrab</name>
    <message>
        <source>Pick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reference system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save picks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot open file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saving to file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting reference points...
  Click on minimum X
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re-using existing reference system
Digitalization of the curve...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    minimum X=%1
  Click on maximum X
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    maximum X=%1
  Click on minimum Y
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    minimum Y=%1
  Click on maximum Y
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    maximum Y=%1
  Reference points set
Digitalization of the curve...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>point (%1): %2 %3 --&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
