#if defined __cplusplus
#include <QtGui>
#include <QtWidgets>
#ifndef Q_OS_MAC
#include <QGpCoreTools.h>
#include <QGpCoreMath.h>
#include <QGpGuiTools.h>
#endif // Q_OS_MAC
#endif // __cplusplus
