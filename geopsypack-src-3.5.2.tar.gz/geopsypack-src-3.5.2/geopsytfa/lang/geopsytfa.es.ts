<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>TFAPlugin</name>
    <message>
        <location filename="../src/TFAPlugin.cpp" line="45"/>
        <location filename="../src/TFAPlugin.h" line="41"/>
        <source>Time frequency analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TFAPlugin.cpp" line="47"/>
        <source>Time-frequency analyses based on Morlet wavelet.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TFAResults</name>
    <message>
        <location filename="../src/TFAResults.cpp" line="76"/>
        <source>Amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TFAResults.cpp" line="93"/>
        <location filename="../src/TFAResults.cpp" line="103"/>
        <source>Time Frequency Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TFAResults.cpp" line="94"/>
        <source>Specified time range does not contain any signal (%1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TFAResults.cpp" line="104"/>
        <source>Time range is probably too large for signal %4 (%5=%6 samples). Given the number of signals (%1), the number of frequency samples (%2), the maximum number of time samples is %3. That corresponds to a total memory consumption of 512 Mb. Contact the developpers if you think that this limit is obsolete according to current computer memories.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TFAResults.cpp" line="128"/>
        <source>Signal %1 : Morlet wavelet convolution at %2 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolTFA</name>
    <message>
        <location filename="../src/ToolTFA.cpp" line="121"/>
        <source>Computation stopped</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolTFAd</name>
    <message>
        <location filename="../src/ToolTFAd.ui" line="14"/>
        <source>TFA toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="23"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="41"/>
        <source>Frequency sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="53"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li {white-space: pre-wrap;}
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p&gt;Modified Morlet Wavelet in spectral domain:&lt;/p&gt;
&lt;p &gt;&lt;/p&gt;
&lt;p&gt;M(f)=1/pow(pi,0.25)*exp((w0*f/fi - w0)^2 * m)&lt;/p&gt;
&lt;p &gt;&lt;/p&gt;
&lt;p&gt;w0, m0 are the wavelet parameters. Theoretically w0&amp;gt;5.5. A typical value for w0 is 6. A typical value for m0 is 10.&lt;/p&gt;
&lt;p &gt;&lt;/p&gt;
&lt;p&gt;fi is the analysed frequency.&lt;/p&gt;
&lt;p &gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="66"/>
        <source>Wavelet parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="86"/>
        <source>Load parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="109"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.ui" line="119"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ToolTFAd.cpp" line="47"/>
        <source>This is just for computing the resolution in time and frequency. It has no influence on the computation of the Morlet transform.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
