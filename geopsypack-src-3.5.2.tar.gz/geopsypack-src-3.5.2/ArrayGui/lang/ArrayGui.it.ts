<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ArrayGui::ArrayResponse</name>
    <message>
        <source>Error computing kmin (linear array?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>kmin: %1 rad/m
kmax: at least %2 rad/m (still searching)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>kmin: %1 rad/m
kmax: %2 rad/m
ground level: %3
kmax-kmin: %4 rad/m
kaverage: %5 rad/m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>kmin: %1 rad/m
kmax: error
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Array transfer function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave number X (rad/m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave length X/(2*pi) (m/rad)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave number Y (rad/m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave length Y/(2*pi) (m/rad)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave number (rad/m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave length/(2*pi) (m/rad)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Array Transfer function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1/Array Transfer function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slowness (s/m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Velocity (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lambda/ArraySize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ArrayGui::RingEditor</name>
    <message>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pairs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Av. radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open rings file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rings file (*.rings)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlockAveragingParameterWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fixed number of blocks par block set (if 0, BLOCK_COUNT_FACTOR is used instead)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Number of block sets par frequency band&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stat. count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;BLOCK_COUNT=&amp;lt;Number of sensors&amp;gt;*BLOCK_COUNT_FACTOR&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Count factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximum overlap between two successive block sets&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> %</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RingEditor</name>
    <message>
        <source>Rings list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total number of couples in rings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To remove the selected ring&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It lets you load a text file containing rings (see format generated by save). Only the first two columns are mandatory.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This tool selects the minimum and maximum radii for all rings. It keeps the selected couples of stations constant in each ring. It is used to get ring as thinner as possible.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Optimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To add a new ring&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Sans Serif; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Save the current list of rings to a text file (.ring)&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Format:&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 1: minimum radius&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 2: maximum radius&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 3: red component index (0 to 255)&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 4: green component index (0 to 255)&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 5: blue component index (0 to 255)&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Col 6: the number of couples selected&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaveNumAnimate</name>
    <message>
        <source>Wave number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>k min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>k max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Azimuth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> °</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
