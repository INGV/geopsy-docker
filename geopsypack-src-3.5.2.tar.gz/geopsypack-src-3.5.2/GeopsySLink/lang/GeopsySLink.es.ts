<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>GeopsySLink::SeedLink</name>
    <message>
        <location filename="../src/SeedLink.cpp" line="146"/>
        <source>Listening to stream %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="164"/>
        <source>Stop listening to stream %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="180"/>
        <source>Active SeedLink signals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="229"/>
        <source>Requesting list of streams...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="236"/>
        <source>Requesting list of stations...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="276"/>
        <source>Requesting streams %1_%2:%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="299"/>
        <source>Resolved %1:%2 into %3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="344"/>
        <source>List of streams downloaded successfully: %1 stations
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="347"/>
        <source>Error parsing xml info received from %1:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="370"/>
        <source>Received packet %1 from %2 to %3 for stream %4
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="387"/>
        <source>Warning: received data for stream &apos;%1&apos;, not listening to that stream
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="392"/>
        <source>Error parsing packet from stream %1, no data downloaded.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="398"/>
        <source>Keep alive packet received
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SeedLink.cpp" line="401"/>
        <source>Received unknown packet
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GeopsySLink::SeedLinkStream</name>
    <message>
        <location filename="../src/SeedLinkStream.cpp" line="148"/>
        <source>In SeedLinkStream::createSignal(), no database specified.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
