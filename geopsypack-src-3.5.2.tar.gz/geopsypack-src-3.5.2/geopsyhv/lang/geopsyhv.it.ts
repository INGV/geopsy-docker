<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>FrequencyWindowRejectionWidget</name>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="14"/>
        <source>Frequency domain window rejection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="20"/>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="46"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Interval can be larger than actual range.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="23"/>
        <source>Minimum frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="30"/>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="56"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="49"/>
        <source>Maximum frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="69"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Recommended value is 2&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="72"/>
        <source>Standard deviation v factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="89"/>
        <source>Maximum number of iterations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FrequencyWindowRejectionWidget.ui" line="106"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This tool rejects time windows according to Cox et al. (2020). You must click on &apos;Start&apos; to update the average curve and the statistics on f0.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Reference:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Cox, B. R., Cheng, T., Vantassel, J. P., &amp;amp; Manuel, L. (2020). A statistical representation and frequency-domain window-rejection algorithm for single-station HVSR measurements. Geophysical Journal International, 221(3), 2170–2183. &lt;a href=&quot;https://doi.org/10.1093/gji/ggaa119&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;https://doi.org/10.1093/gji/ggaa119&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVPlugin</name>
    <message>
        <location filename="../src/HVPlugin.cpp" line="50"/>
        <source>Spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="52"/>
        <source>Smoothed amplitude spectrum.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="57"/>
        <source>H/V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="59"/>
        <source>Horizontal to vertical ratio for ambient vibrations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="64"/>
        <source>Spectrum Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="66"/>
        <source>Smoothed horizontal amplitude spectrum, scans in all directions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="71"/>
        <source>H/V Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="73"/>
        <source>Horizontal to vertical ratio for ambient vibrations, scans in all directions for the horizontal component.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.cpp" line="107"/>
        <source>HV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVPlugin.h" line="45"/>
        <source>H/V and Spectal ratios</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVResultSheet</name>
    <message>
        <location filename="../src/HVResultSheet.cpp" line="44"/>
        <source>H/V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVResultSheet.cpp" line="60"/>
        <source>H/V Results - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVResultSheet.cpp" line="68"/>
        <source>Load H/V results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVResultSheet.cpp" line="68"/>
        <source>HV file (*.hv)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVRotateResultSheet</name>
    <message>
        <location filename="../src/HVRotateResultSheet.cpp" line="46"/>
        <source>H/V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVRotateResultSheet.cpp" line="62"/>
        <source>H/V Rotate Results - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVRotateToolWidget</name>
    <message>
        <location filename="../src/HVRotateToolWidget.cpp" line="48"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVRotateToolWidget.cpp" line="49"/>
        <source>North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVRotateToolWidget.cpp" line="50"/>
        <source>East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVRotateToolWidget.cpp" line="63"/>
        <source>H/V Rotate toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVSummary</name>
    <message>
        <location filename="../src/HVSummary.cpp" line="59"/>
        <source>H/V summary - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVSummary.cpp" line="74"/>
        <source>H/V</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HVToolWidget</name>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="44"/>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="45"/>
        <source>North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="46"/>
        <source>East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="51"/>
        <source>Frequency rejection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="64"/>
        <source>H/V toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="109"/>
        <source>Frequency window rejection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HVToolWidget.cpp" line="109"/>
        <source>Encountered error(s)

%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectrumResultSheet</name>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="55"/>
        <source>Spectrum Results - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="64"/>
        <source>&amp;Derivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="65"/>
        <source>Derivate the selected spectra.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="69"/>
        <source>&amp;Integrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="70"/>
        <source>Integrate the selected spectra.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="79"/>
        <source>Derivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="96"/>
        <source>Integrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="122"/>
        <source>Load spectrum results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumResultSheet.cpp" line="122"/>
        <source>Spectrum file (*.spec)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectrumRotateResultSheet</name>
    <message>
        <location filename="../src/SpectrumRotateResultSheet.cpp" line="61"/>
        <source>Horizontal Spectrum Rotate Results - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectrumRotateToolWidget</name>
    <message>
        <location filename="../src/SpectrumRotateToolWidget.cpp" line="49"/>
        <source>Any component</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumRotateToolWidget.cpp" line="63"/>
        <source>Power spectral density [(%1)^2/Hz]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumRotateToolWidget.cpp" line="65"/>
        <source>Horizontal Spectrum Rotate toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectrumSummary</name>
    <message>
        <location filename="../src/SpectrumSummary.cpp" line="46"/>
        <source>Spectrum summary - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectrumToolWidget</name>
    <message>
        <location filename="../src/SpectrumToolWidget.cpp" line="51"/>
        <source>Any component</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumToolWidget.cpp" line="66"/>
        <source>Power spectral density [(%1)^2/Hz]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SpectrumToolWidget.cpp" line="71"/>
        <source>Spectrum toolbox - </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabHVPreferences</name>
    <message>
        <location filename="../src/TabHVPreferences.ui" line="13"/>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TabHVPreferences.cpp" line="43"/>
        <source>Spectrum options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/TabHVPreferences.cpp" line="45"/>
        <source>H/V options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
